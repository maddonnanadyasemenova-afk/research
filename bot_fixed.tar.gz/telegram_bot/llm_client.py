import os
import httpx
from typing import List, Dict

# Используем встроенный Manus LLM API
MANUS_LLM_URL = os.getenv('BUILT_IN_FORGE_API_URL', 'https://api.manus.im')
MANUS_API_KEY = os.getenv('BUILT_IN_FORGE_API_KEY', '')


async def invoke_llm(messages: List[Dict[str, str]], max_tokens: int = 4000) -> str:
    """
    Вызов Manus LLM API для генерации ответа
    
    Args:
        messages: Список сообщений в формате [{"role": "user", "content": "..."}]
        max_tokens: Максимальное количество токенов в ответе
    
    Returns:
        Текст ответа от LLM
    """
    url = f"{MANUS_LLM_URL}/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {MANUS_API_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": 0.7
    }
    
    async with httpx.AsyncClient(timeout=120.0) as client:
        response = await client.post(url, json=payload, headers=headers)
        response.raise_for_status()
        
        data = response.json()
        return data['choices'][0]['message']['content']
